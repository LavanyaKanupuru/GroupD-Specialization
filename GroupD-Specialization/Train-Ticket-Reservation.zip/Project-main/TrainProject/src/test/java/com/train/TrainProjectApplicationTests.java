package com.train;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
